/** @format */
import Player from "./Player.js";
import Monster from "./Monster.js";
import Fire from "./Fire.js";

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth * 0.8;
canvas.height = window.innerHeight * 0.8;
const player = new Player(250, 250, 0);
const monster = new Monster(canvas.width, 0, 100);
const fire = new Fire(player.x, player.y);
//GAME LOOP

function gameLoop() {
	setScreen();
	player.draw();
	monster.draw();
}

// OtherFunctions/
function setScreen() {
	ctx.fillStyle = "black";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
}

setInterval(gameLoop, 1000 / 24);
