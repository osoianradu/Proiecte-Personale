/** @format */

export default class Monster {
	space = false;
	constructor(x, y, speed, width, height) {
		this.x = x;
		this.start_x = x;
		this.y = 100;
		this.width = 50;
		this.height = 50;
		this.speed;
		this.image = new Image();
		this.image.src = "images/Monstrii/monstru_1.png";
		this.canvas = document.getElementById("game");
		this.ctx = this.canvas.getContext("2d");

		document.addEventListener("keydown", this.keydown);
		document.addEventListener("keyup", this.keyup);
	}

	draw() {
		this.ctx.drawImage(this.image, this.x, this.y, this.width, this.height);
		this.move();
		this.collideWithWalls();
	}

	collideWithWalls() {
		if (this.x < 0) {
			this.x = this.start_x;
			this.y = this.y = Math.floor(Math.random() * (this.height + 1));
		}
		if (this.x > this.canvas.width - this.width) {
			this.x = this.canvas.width - this.width;
		}
		if (this.y < 0) {
			this.y = 0;
		}
		if (this.y > this.canvas.height - this.height) {
			this.x = this.canvas.height - this.height;
		}
	}

	keydown = (event) => {
		if (event.code == "Space") {
			if (this.space) {
				this.space = false;
			} else {
				this.space = true;
			}
		}
	};

	keyup = (event) => {
		if (event.code == "Space") {
			//this.space = false;
		}
	};
	move() {
		if (this.space) {
			for (let i = 0; i < 10; i++) {
				this.x -= 1;
			}
		}
	}
}
